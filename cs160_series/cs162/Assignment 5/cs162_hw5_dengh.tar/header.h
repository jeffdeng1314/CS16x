/*********************************************************************
 * ** Function: header
 * ** Description: the header file
 * ** Parameters:n/a
 * ** Pre-Conditions:n/a
 * ** Post-Conditions: provide libraries for the program
 * ** Return:n/a
*********************************************************************/
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//                  