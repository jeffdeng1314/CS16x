#include "states_fact.h"

/******************************************************
 * ** Program: assignment_1.cpp
 * ** Author: Jeff Deng
 * ** Date: 04/16/2017
 * ** Description: sort out all the data from the file that the user inputs
 * ** Input: header file, libraries
 * ** Output: calling functions
 * ******************************************************/
int main(int argc, char **argv){

	bool valid= true,checking=true;
	int num_states;
	valid = is_valid_arguments(argv,argc);


	if(valid == true){
		return 0;
	}	
}
