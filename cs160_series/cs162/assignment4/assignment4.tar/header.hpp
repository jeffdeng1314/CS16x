#pragma once
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <string>
#include <cmath>
#include <cstring>
using namespace std;

/*********************************************************************
 * ** Program:Assignment_4
 * ** Description:RPG game 
 * ** Author: Jeff Deng
 * ** Date: 05/28/2017
 * ** Input: pokemons, libraries, location, grips
 * ** Output: giving the user the choice to play and pick
*********************************************************************/
