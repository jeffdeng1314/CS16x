#pragma once
#include "header.hpp"
#include "event.hpp"

/*********************************************************************
 * ** Function: cave
 * ** Description: cave class
 * ** Parameters: n/a
 * ** Pre-Conditions:n/a
 * ** Post-Conditions:n/a
 * ** Return:n/a
*********************************************************************/
class cave:public event{

protected:
	int mega_stones;
public:
	cave();
	void set_value();
	int get_mega_stones();
	void encounter();
	char indicator();

};