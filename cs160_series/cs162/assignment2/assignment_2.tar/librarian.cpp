#pragma once
#include "header.h"
#include "cart.h"
#include "librarian.h"
#include "library.h"
#include "structs.h"
#include "patron.h"
//////////////////////The cart, patron, and librarian constructors are from the pair programming///////////////////
/*********************************************************************
 * ** Function:Librarian
 * ** Description:librarian constructor
 * ** Parameters: n/a
 * ** Pre-Conditions:declared in public 
 * ** Post-Conditions:runs when librarian object is reacted
 * ** Return:n/a
 * *********************************************************************/ 
librarian::librarian(){
	name = "Your name please";
	id = 0;

}





//librarian::~librarian()
