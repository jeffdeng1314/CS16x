#pragma once
#include "creature.h"
#include "header.h"

/*********************************************************************
 * ** Function:human
 * ** Description:human class
 * ** Parameters:n/a
 * ** Pre-Conditions:n/a
 * ** Post-Conditions:n/a
 * ** Return:n/a
*********************************************************************/
class human:public creature{

	protected:
	//	int num_human;
	public:
		human();	
	//	void set_num_human();
	//	int get_num_human();

};
