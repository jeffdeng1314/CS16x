#pragma once
#include "creature.h"
#include "header.h"

/*********************************************************************
 * ** Function:dragon
 * ** Description:dragon class
 * ** Parameters:n/a
 * ** Pre-Conditions:n/a
 * ** Post-Conditions:n/a
 * ** Return:n/a
*********************************************************************/
class dragon:public creature{

	protected:
	public:
		dragon();	

};
