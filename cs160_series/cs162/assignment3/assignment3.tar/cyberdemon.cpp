#include "cyberdemon.h"
#include "header.h"
#include "demon.h"

/*********************************************************************
 * ** Function:cyberdemon
 * ** Description:class
 * ** Parameters:n/a
 * ** Pre-Conditions:n/a
 * ** Post-Conditions:n/a
 * ** Return:n/a
*********************************************************************/
cyberdemon::cyberdemon(){


//	cout <<"Balrog constructor"<<endl;	
	type = 1;
	strength = 20;
	hitpoints = 300;
	payoff = 300;
	cost = 250;	

}

