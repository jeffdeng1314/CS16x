#include "creature.h"
#include "balrog.h"
#include "header.h"
#include "demon.h"

/*********************************************************************
 * ** Function:balrog
 * ** Description:constructor
 * ** Parameters:n/a
 * ** Pre-Conditions:n/a
 * ** Post-Conditions:n/a
 * ** Return:n/a
*********************************************************************/
balrog::balrog(){


//	cout <<"Balrog constructor"<<endl;	
	type = 2;
	strength = 13;
	hitpoints = 175;
	payoff = 200;
	cost = 150;	

}

