#pragma once
#include "demon.h"
#include "creature.h"
#include "header.h"


/*********************************************************************
 * ** Function:cyberdemon
 * ** Description:cyberdemon class
 * ** Parameters:n/a
 * ** Pre-Conditions:n/a
 * ** Post-Conditions:n/a
 * ** Return:n/a
*********************************************************************/
class cyberdemon:public demon{

	public:
		cyberdemon();

};
