#pragma once
#include "header.h"
#include "creature.h"



/*********************************************************************
 * ** Function:elf
 * ** Description:class
 * ** Parameters:n/a
 * ** Pre-Conditions:n/a
 * ** Post-Conditions:n/a
 * ** Return:n/a
*********************************************************************/
class elf:public creature{

	public:
	elf();
};
