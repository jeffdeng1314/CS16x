#include "header.h"
#include "creature.h"
#include "dragon.h"


/*********************************************************************
 * ** Function:dragon
 * ** Description:constrcutor
 * ** Parameters:n/a
 * ** Pre-Conditions:n/a
 * ** Post-Conditions:n/a
 * ** Return:n/a
*********************************************************************/
dragon::dragon(){

	type = 4;
	strength = 35;
	hitpoints = 700;
	payoff = 340;
	cost = 1000;	
	
}


