#pragma once
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <string>
using namespace std;

/*********************************************************************
 * ** Program:Assignment_3
 * ** Description:RPG game 
 * ** Author: Jeff Deng
 * ** Date: 05/12/2017
 * ** Input: libraries, main function, classes, and all other functions
 * ** Output: giving the user the choice to play and pick
*********************************************************************/


