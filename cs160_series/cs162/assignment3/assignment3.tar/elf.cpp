#include "elf.h"
#include "creature.h"
#include "header.h"


/*********************************************************************
 * ** Function:elf
 * ** Description:constructor
 * ** Parameters:n/a
 * ** Pre-Conditions:n/a
 * ** Post-Conditions:n/a
 * ** Return:n/a
*********************************************************************/
elf::elf(){

//	cout <<"ELF constructor"<<endl;	
	type = 3;
	strength = 15;
	hitpoints = 150;
	payoff = 250;
	cost = 175;	


}



