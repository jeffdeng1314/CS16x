#pragma once
#include "demon.h"
#include "creature.h"
#include "header.h"


/*********************************************************************
 * ** Function:balrog
 * ** Description:class
 * ** Parameters:n/a
 * ** Pre-Conditions:n/a
 * ** Post-Conditions:n/a
 * ** Return:n/a
*********************************************************************/
class balrog:public demon{

	public:
		balrog();

};
