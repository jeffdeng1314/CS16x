#pragma once
#include "header.h"
#include "creature.h"
//#include "balrog.h"



class demon:public creature{

};
